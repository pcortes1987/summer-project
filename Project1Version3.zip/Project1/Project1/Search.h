#pragma once

namespace Project1 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Search
	/// </summary>
	public ref class Search : public System::Windows::Forms::Form
	{
	public:
		Search(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Search()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected:
	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::Button^  btnUpdate;
	private: System::Windows::Forms::Button^  btnView;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->btnUpdate = (gcnew System::Windows::Forms::Button());
			this->btnView = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(43, 21);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(287, 18);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Enter the ID of the person you want to find:";
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(110, 60);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(144, 20);
			this->textBox1->TabIndex = 1;
			// 
			// btnUpdate
			// 
			this->btnUpdate->Location = System::Drawing::Point(81, 101);
			this->btnUpdate->Name = L"btnUpdate";
			this->btnUpdate->Size = System::Drawing::Size(75, 23);
			this->btnUpdate->TabIndex = 2;
			this->btnUpdate->Text = L"Update";
			this->btnUpdate->UseVisualStyleBackColor = true;
			this->btnUpdate->Click += gcnew System::EventHandler(this, &Search::btnUpdate_Click);
			// 
			// btnView
			// 
			this->btnView->Location = System::Drawing::Point(200, 101);
			this->btnView->Name = L"btnView";
			this->btnView->Size = System::Drawing::Size(75, 23);
			this->btnView->TabIndex = 3;
			this->btnView->Text = L"View Details";
			this->btnView->UseVisualStyleBackColor = true;
			// 
			// Search
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(370, 159);
			this->Controls->Add(this->btnView);
			this->Controls->Add(this->btnUpdate);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->label1);
			this->Name = L"Search";
			this->Text = L"Search";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnUpdate_Click(System::Object^  sender, System::EventArgs^  e)
	{
		/*String ^ num = txtNumSearch->Text;
		string ID = msclr::interop::marshal_as<string>(num);

		//search thru student txt file/db and find the ID
		//input them into variables
		//what do u want to update?
		//save the new thing in variable
		//loop thru file again and put it back where it belongs
		*/
	}

	private: System::Void btnView_Click(System::Object^  sender, System::EventArgs^  e)
	{
		/*
		String ^ num = txtNumSearch->Text;
		string ID = msclr::interop::marshal_as<string>(num);

		//search thru student txt file/db and find the ID
		//input them into variables
		//display them in either a table, listbox, textbox etc.
		*/
	}
	};
}
