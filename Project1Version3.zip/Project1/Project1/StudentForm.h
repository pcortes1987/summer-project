#pragma once

namespace Project1 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for StudentForm
	/// </summary>
	public ref class StudentForm : public System::Windows::Forms::Form
	{
	public:
		StudentForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~StudentForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Button^  btnStudentView;
	private: System::Windows::Forms::Button^  btnExamView;

	private: System::Windows::Forms::Button^  btnCourseView;
	private: System::Windows::Forms::Button^  btnGPAView;


	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->btnStudentView = (gcnew System::Windows::Forms::Button());
			this->btnExamView = (gcnew System::Windows::Forms::Button());
			this->btnCourseView = (gcnew System::Windows::Forms::Button());
			this->btnGPAView = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(174, 9);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(187, 24);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Welcome, Student!";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(195, 17);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(0, 13);
			this->label2->TabIndex = 1;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(185, 44);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(166, 16);
			this->label3->TabIndex = 2;
			this->label3->Text = L"What would you like to do\?";
			// 
			// btnStudentView
			// 
			this->btnStudentView->Location = System::Drawing::Point(28, 104);
			this->btnStudentView->Name = L"btnStudentView";
			this->btnStudentView->Size = System::Drawing::Size(108, 39);
			this->btnStudentView->TabIndex = 3;
			this->btnStudentView->Text = L"View Student Details";
			this->btnStudentView->UseVisualStyleBackColor = true;
			// 
			// btnExamView
			// 
			this->btnExamView->Location = System::Drawing::Point(293, 104);
			this->btnExamView->Name = L"btnExamView";
			this->btnExamView->Size = System::Drawing::Size(82, 39);
			this->btnExamView->TabIndex = 4;
			this->btnExamView->Text = L"Exam Scores";
			this->btnExamView->UseVisualStyleBackColor = true;
			// 
			// btnCourseView
			// 
			this->btnCourseView->Location = System::Drawing::Point(165, 104);
			this->btnCourseView->Name = L"btnCourseView";
			this->btnCourseView->Size = System::Drawing::Size(101, 39);
			this->btnCourseView->TabIndex = 5;
			this->btnCourseView->Text = L"Courses Currently Registered";
			this->btnCourseView->UseVisualStyleBackColor = true;
			// 
			// btnGPAView
			// 
			this->btnGPAView->Location = System::Drawing::Point(404, 104);
			this->btnGPAView->Name = L"btnGPAView";
			this->btnGPAView->Size = System::Drawing::Size(89, 39);
			this->btnGPAView->TabIndex = 6;
			this->btnGPAView->Text = L"Semester GPA";
			this->btnGPAView->UseVisualStyleBackColor = true;
			// 
			// StudentForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(525, 199);
			this->Controls->Add(this->btnGPAView);
			this->Controls->Add(this->btnCourseView);
			this->Controls->Add(this->btnExamView);
			this->Controls->Add(this->btnStudentView);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"StudentForm";
			this->Text = L"Student Menu";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	};
}
