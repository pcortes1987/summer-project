#pragma once
#include <iostream>
#include <string>
#include <fstream>
#include "AdminForm.h"
#include "StudentForm.h"
#include <msclr\marshal.h>
#include <vcclr.h>
#include <msclr\marshal_cppstd.h>

namespace Project1 {

	using namespace System;
	using namespace std;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected:
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::ComboBox^  comboBox1;
	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::TextBox^  textBox2;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::CheckBox^  adminBox;
	private: System::Windows::Forms::CheckBox^  studentBox;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->adminBox = (gcnew System::Windows::Forms::CheckBox());
			this->studentBox = (gcnew System::Windows::Forms::CheckBox());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(69, 29);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(473, 20);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Welcome to the Student Information Management System";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(184, 157);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(74, 16);
			this->label2->TabIndex = 1;
			this->label2->Text = L"Username:";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(187, 222);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(71, 16);
			this->label3->TabIndex = 2;
			this->label3->Text = L"Password:";
			// 
			// comboBox1
			// 
			this->comboBox1->DisplayMember = L"Student;Admin";
			this->comboBox1->FormattingEnabled = true;
			this->comboBox1->Items->AddRange(gcnew cli::array< System::Object^  >(2) { L"Admin", L"Student" });
			this->comboBox1->Location = System::Drawing::Point(254, 118);
			this->comboBox1->Name = L"comboBox1";
			this->comboBox1->Size = System::Drawing::Size(121, 21);
			this->comboBox1->TabIndex = 3;
			this->comboBox1->ValueMember = L"Student;Admin";
			this->comboBox1->SelectedIndexChanged += gcnew System::EventHandler(this, &MyForm::comboBox1_SelectedIndexChanged);
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(264, 153);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(100, 20);
			this->textBox1->TabIndex = 4;
			// 
			// textBox2
			// 
			this->textBox2->Location = System::Drawing::Point(264, 222);
			this->textBox2->Name = L"textBox2";
			this->textBox2->Size = System::Drawing::Size(100, 20);
			this->textBox2->TabIndex = 5;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(114, 87);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(144, 16);
			this->label4->TabIndex = 6;
			this->label4->Text = L"Choose a type of user: ";
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(236, 272);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(120, 23);
			this->button1->TabIndex = 7;
			this->button1->Text = L"Login";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// adminBox
			// 
			this->adminBox->AutoSize = true;
			this->adminBox->Location = System::Drawing::Point(264, 86);
			this->adminBox->Name = L"adminBox";
			this->adminBox->Size = System::Drawing::Size(55, 17);
			this->adminBox->TabIndex = 8;
			this->adminBox->Text = L"Admin";
			this->adminBox->UseVisualStyleBackColor = true;
			// 
			// studentBox
			// 
			this->studentBox->AutoSize = true;
			this->studentBox->Location = System::Drawing::Point(337, 86);
			this->studentBox->Name = L"studentBox";
			this->studentBox->Size = System::Drawing::Size(63, 17);
			this->studentBox->TabIndex = 9;
			this->studentBox->Text = L"Student";
			this->studentBox->UseVisualStyleBackColor = true;
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(592, 319);
			this->Controls->Add(this->studentBox);
			this->Controls->Add(this->adminBox);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->textBox2);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->comboBox1);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"MyForm";
			this->Text = L"MyForm";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) 
{
	//if (comboBox1->SelectedItem->ToString = "Admin")
	if (adminBox->Checked && !studentBox->Checked)
	{
		string word;
		string next;
		ifstream inFile;
		inFile.open("admin.txt");

		string userName = textBox1->Text->ToString;
		string password = textBox2->Text->ToString;

		string searchUserName = msclr::interop::marshal_as<string>(userName);
		string searchPassword = msclr::interop::marshal_as<string>(password);

		while (inFile >> word)
		{
			if (word.compare(searchUserName) == 0)
			{
				inFile >> word >> next;
				if (next.compare(searchPassword) == 0)
				{
					AdminForm ^ form = gcnew AdminForm;
				}
			}
		}
	}

	//else if (comboBox1->SelectedItem->ToString = "Student")
	else if (!adminBox->Checked && studentBox->Checked)
	{
		string word;
		string next;
		ifstream inFile;
		inFile.open("student.txt");

		string userName = textBox1->Text->ToString;
		string password = textBox2->Text->ToString;

		string searchUserName = msclr::interop::marshal_as<string>(userName);
		string searchPassword = msclr::interop::marshal_as<string>(password);

		while (inFile >> word)
		{
			if (word.compare(searchUserName) == 0)
			{
				inFile >> word >> next;
				if (next.compare(searchPassword) == 0)
				{
					StudentForm ^ form = gcnew StudentForm;
				}
			}
		}
	}

	else
		MessageBox::Show("Only Check One Box");
}

private: System::Void comboBox1_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {
}
};
}
